<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku - FTIK</title>
    <link rel="stylesheet" href="<?php echo e(url('style.css')); ?>">
</head>
<body>
    <h2 class="judul">Edit Buku</h2>
    <br>
    <form action="<?php echo e(url('buku/save')); ?>"method="get">
    <?php echo csrf_field(); ?> 
        <input type="hidden" name="id" value="<?php echo e($query->ID_Buku); ?>"/>
        <input type="hidden" name="is_update"value="<?php echo e($is_update); ?>"/>
        Judul : <input type="text" name="Judul" value="<?php echo e($query->Judul); ?>"size='50'maxlength='150'/>
        <br/><br/>
        Pengarang : <input type="text" name="Pengarang" value="<?php echo e($query->Pengarang); ?>"size='50'maxlength='150'/>
        <br/><br/>
        Kategori : <select name="Kategori">
            <?php $__currentLoopData = $optkategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($query->Kategori == $key): ?>
                <option value="<?php echo e($key); ?>"selected><?php echo e($value); ?></option>
                <?php else: ?>
                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br/><br/><input type="submit"name="btn_simpan"value="Simpan"/>
    </form>
    <br/><a href="<?php echo e(url('buku')); ?>">kembali</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/buku/edit.blade.php ENDPATH**/ ?>