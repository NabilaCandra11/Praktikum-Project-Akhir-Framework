<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pinjam Buku - FTIK</title>
    <link rel="stylesheet" href="<?php echo e(url('style.css')); ?>">
</head>
<body>
<?php if($errors->any()): ?>
<div>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($errors); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
    <form action="<?php echo e(url('pinjam/save')); ?>" method="get">
    <?php echo csrf_field(); ?> 
        <h2 class="judul">Pinjam Buku</h2>
        <input type="hidden" name="id" value=""/>
        <input type="hidden" name="is_update" value="<?php echo e($is_update); ?>"/>
        <br/><br/>
        Anggota : 
        <select type="text" name="ID_Anggota" width="200px;">
        <option value="" disabled selected>Pilih Anggota</option>
            <?php $__currentLoopData = $optpinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(old('ID_Anggota')==$key): ?>
                <option value="<?php echo e($key); ?>"selected><?php echo e($value); ?></option>
                <?php else: ?>
                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br/><br/>
        Buku :
        <select type="text" name="ID_Buku" width="200px;">
        <option value="" disabled selected>Pilih Buku</option>
            <?php $__currentLoopData = $optpinjam1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(old('ID_Buku')==$key): ?>
                <option value="<?php echo e($key); ?>"selected><?php echo e($value); ?></option>
                <?php else: ?>
                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br><br>Tanggal Pinjam <input type="date" name="Tgl_Pinjam" value="<?php echo e(old('Tgl_Pinjam')); ?>">
        <br><br>Tanggal Kembali <input type="date" name="Tgl_Kembali" value="<?php echo e(old('Tgl_Kembali')); ?>">
        <br/><br/><input type="submit" name="btn_simpan" value="Simpan"/><input type="reset" value="Batal">
    </form>
    <br/><a href="<?php echo e(url('pinjam')); ?>">kembali</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/pinjam/add.blade.php ENDPATH**/ ?>