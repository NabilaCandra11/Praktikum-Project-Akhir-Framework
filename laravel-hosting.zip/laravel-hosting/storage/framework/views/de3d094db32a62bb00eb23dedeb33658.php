<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Anggota - FTIK</title>
    <link rel="stylesheet" href="<?php echo e(url('style.css')); ?>">
</head>
<body>
    <h2 class="judul">Tambah Anggota</h2>
    <br>
    <?php if($errors->any()): ?>
    <div>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($errors); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <form action="<?php echo e(url('anggota/save')); ?>" method="get">
    <?php echo csrf_field(); ?> 
        <input type="hidden" name="id" value=""/>
        <input type="hidden" name="is_update" value="<?php echo e($is_update); ?>"/>
        NIM : <input type="text" name="NIM" value="<?php echo e(old('NIM')); ?>" size="50" maxlength="100"/>
        <br/><br/>Nama : <input type="text" name="Nama" value="<?php echo e(old('Nama')); ?>" size="50" maxlength="150"/>
        <br/><br/>Progdi : 
        <select type="text" name="Progdi">
            <?php $__currentLoopData = $optprogdi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(old('Progdi')==$key): ?>
                <option value="<?php echo e($key); ?>"selected><?php echo e($value); ?></option>
                <?php else: ?>
                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br/><br/><input type="submit" name="btn_simpan" value="Simpan"/>
    </form>
    <br/><a href="<?php echo e(url('anggota')); ?>">kembali</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/anggota/add.blade.php ENDPATH**/ ?>