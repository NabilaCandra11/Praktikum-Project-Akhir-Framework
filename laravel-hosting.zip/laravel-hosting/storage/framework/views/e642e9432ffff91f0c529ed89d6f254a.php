<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Anggota - FTIK</title>
    <link rel="stylesheet" href="<?php echo e(url('style.css')); ?>">
</head>
<body>
    <h2 class="judul">Edit Anggota</h2>
    <form action="<?php echo e(url('anggota/save')); ?>"method="get">
    <br>
    <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($query->ID_Anggota); ?>"/>
        <input type="hidden" name="is_update"value="<?php echo e($is_update); ?>"/>
        NIM : <input type="text" name="NIM" value="<?php echo e($query->NIM); ?>"size='50'maxlength='150'/>
        <br/><br/>
        Nama : <input type="text" name="Nama" value="<?php echo e($query->Nama); ?>"size='50'maxlength='150'/>
        <br/><br/>
        Progdi <select name="Progdi">
            <?php $__currentLoopData = $optprogdi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($query->Progdi == $key): ?>
                <option value="<?php echo e($key); ?>"selected><?php echo e($value); ?></option>
                <?php else: ?>
                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br/><br/><input type="submit"name="btn_simpan"value="simpan"/>
    </form>
    <br/><a href="<?php echo e(url('anggota')); ?>">kembali</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/anggota/edit.blade.php ENDPATH**/ ?>