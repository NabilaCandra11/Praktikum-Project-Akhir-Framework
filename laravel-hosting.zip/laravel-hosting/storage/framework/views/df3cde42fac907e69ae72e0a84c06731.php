<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Buku - FTIK</title>
    <link rel="stylesheet" href="<?php echo e(url('style.css')); ?>">
</head>
<body>
    <h2 class="judul">Daftar Buku</h2>
    <br>
    <a href="<?php echo e(url('buku/add')); ?>" class="border">Tambah Buku</a><br/><br/>
    <table border="1">
        <tr>
            <th>No</th>
            <th>ID Buku</th>
            <th>Judul</th>
            <th>Pengarang</th>
            <th>Kategori</th>
            <th>Aksi</th>
        </tr>
    <?php
        $no=0;
    ?>
    <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $no++;
        ?>
        <tr>
            <td><?php echo e($no); ?></td>
            <td><?php echo e($row['ID_Buku']); ?></td>
            <td><?php echo e($row['Judul']); ?></td>
            <td><?php echo e($row['Pengarang']); ?></td>
            <td><?php echo e($row['Kategori']); ?></td>
            <td><a href=<?php echo e(url('buku/edit/'.$row['ID_Buku'])); ?> class="border-edit">Edit</a>
                <a href=<?php echo e(url('buku/delete/'.$row['ID_Buku'])); ?> class="border-delete"
                onclick="return confirm('Yakin?')">Delete</a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <br>
    <p><?php echo e($query->links('vendor.pagination.mypage')); ?></p>
    <br>
    <a href="/perpus" class="border">Home</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/buku/list.blade.php ENDPATH**/ ?>