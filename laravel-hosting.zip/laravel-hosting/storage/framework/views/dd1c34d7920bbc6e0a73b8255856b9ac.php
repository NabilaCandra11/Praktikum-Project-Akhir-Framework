<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Anggota - FTIK</title>
    <link rel="stylesheet" href="<?php echo e(url('style.css')); ?>">
</head>
<body>
    <h2 class="judul">Daftar Anggota</h2>
    <br>
    <a href="<?php echo e(url('anggota/add')); ?>" class="border">Tambah Anggota</a><br/><br/>
    <table border="1">
        <tr>
            <th>No</th>
            <th>ID Anggota</th>
            <th>NIM</th>
            <th>Nama</th>
            <th>Progdi</th>
            <th>Aksi</th>
        </tr>
    <?php
        $no=0;
    ?>
    <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $no++;
        ?>
        <tr>
            <td><?php echo e($no); ?></td>
            <td><?php echo e($row['ID_Anggota']); ?></td>
            <td><?php echo e($row['NIM']); ?></td>
            <td><?php echo e($row['Nama']); ?></td>
            <td><?php echo e($row['Progdi']); ?></td>
            <td><a href=<?php echo e(url('anggota/edit/'.$row['ID_Anggota'])); ?> class="border-edit">Edit</a>
                <a href=<?php echo e(url('anggota/delete/'.$row['ID_Anggota'])); ?> class="border-delete"
                onclick="return confirm('Yakin?')">Delete</a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <br>
    <p><?php echo e($query->links('vendor.pagination.mypage')); ?></p>
    <br>
    <a href="<?php echo e(url('/perpus')); ?>" class="border">Home</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/anggota/list.blade.php ENDPATH**/ ?>